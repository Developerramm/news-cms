<div id ="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <span>© Copyright 2024 News | Powered by <a href="#">Ram Kumar</a></span>
            </div>
        </div>
    </div>
</div>
</body>
</html>
