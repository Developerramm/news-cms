<?php

$conn = mysqli_connect("localhost","root","","news") or die("Connection failed".mysqli_connect_error());

$hostname = "http://localhost/news";

?>